@echo off
chcp 1251 > nul
cd /d "C:\PLUGINS\FAIvents"
echo Сборка FAIvents...
call mvn clean package
if %errorlevel% equ 0 (
    echo ✅ Готово!
) else (
    echo ❌ Ошибка!
)
close